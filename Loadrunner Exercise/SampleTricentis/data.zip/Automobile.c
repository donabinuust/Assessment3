Automobile()
{

	lr_start_transaction("select vehicle");

	return 0;
}